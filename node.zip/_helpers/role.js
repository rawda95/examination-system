module.exports = {
    Admin: 'Admin',
    Student: 'Student',
    Emp: 'Emp',
    Teacher: 'Teacher',
}