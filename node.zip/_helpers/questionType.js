module.exports = {
    Choice: 'Choice',
    TrueOrFalse: 'TrueOrFalse',
    Text: 'Text',
    Code: 'Code'

};