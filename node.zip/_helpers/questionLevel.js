module.exports = {
    Hard: 'Hard',
    Easy: 'Easy',
    Normal: 'Normal'
};